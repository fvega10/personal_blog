<!DOCTYPE html>
<html lang="es">
<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
	
	<title>
		FVU | Mi portafolio estilo Blog		
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta name="HandleFriedly" content="true" />
	
	<meta name="description" content="Aplicación web, html, php, js, materialize">
	<meta name="keywords" content="Fabricio, Fabricio Vega, Fabricio Vega Ugalde, Blog, Tecnología">
	<meta name="author" content="Fabricio Vega">
	<link rel="icon" type="image/vnd.microsoft.icon" href="/assets/media/icono.ico">
	<link rel="shortcut icon" type="image/x-icon" href="/assets/media/icono.ico">
	<link rel="stylesheet" href="/assets/css/style.css">
	<link rel="stylesheet" href="/assets/css/aos.min.css">
	<link rel="stylesheet" href="/assets/css/all.css">

    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      
</head>
<body>
	<div>