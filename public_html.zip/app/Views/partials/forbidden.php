<div class="forbidden">
	<div class="row">
		<div class="col s12">
			<nav>
				<div class="nav-wrapper">
				<a href="/index.php" class="brand-logo">FV</a>
				<ul id="nav-mobile" class="right hide-on-med-and-down">
					<li>
						<a class="dropdown-item" href="/authenticate/index.php?action=login">
							Iniciar sesión
						</a>
					</li>
				</ul>
				</div>
			</nav>
		</div>
	</div>
	<div class="row">
		<div class="col s12 center-align">
			<img src="/assets/media/403-Forbidden-HTML.gif" alt="Prohibido" width="70%">
		</div>
	</div>
</div>



